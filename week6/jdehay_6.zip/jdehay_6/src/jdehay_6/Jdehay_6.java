package jdehay_6;

/**
 * @Course: SDEV 250 ~ Java Programming I
 * @Author Name: Jeremy DeHay
 * @Assignment Name: jdehay_6
 * @Date: Oct 18, 2017
 * @Description: Week 6 Assignment: Methods. This program takes user input for
 * last months and the current months KwHs, determines how much was used, and
 * calculates the subtotal and total cost for the usage.
 */
//Imports
import java.util.InputMismatchException;
import java.util.Scanner;

//Begin Class Jdehay_6
public class Jdehay_6 {

    /* Global constants */
    

    //Begin Main Method
    public static void main(String[] args) {
        
        final double RATE_A = .0809;
        final double RATE_B = .091;
        final double RATE_C = .109;
        final double TAX = .0346;
        final Scanner INPUT = new Scanner(System.in);
        
        /* variables */
        double lastMonth;
        double currentMonth;
        double usage;
        double subtotal;
        double taxOwed;
        double rate;
        char cont;

        /* Validate entries for last month and current month meter readings */
        while (true) {
            try {
                System.out.print("Enter last month's KwHs usage: ");
                lastMonth = INPUT.nextDouble();
                System.out.print("Enter the current month's KwHs usage: ");
                currentMonth = INPUT.nextDouble();
            } catch (InputMismatchException e) {
                INPUT.nextLine();
                System.out.println("Input error, please try again.");
                continue;
            }
            
            /* Calculate usage, rate, subtotal, and taxes owed */
            usage = getUsage(lastMonth, currentMonth);
            
            System.out.printf("Your usage was: %.1f KwHs\n", usage);
            
            if (usage > 900) {
                rate = RATE_C;
            } else if (usage > 500) {
                rate = RATE_B;
            } else
                rate = RATE_A;
            
            subtotal = getSubtotal(usage, rate);
            taxOwed = getTax(subtotal, TAX);

            /* Output calculation results */
            System.out.printf("Your rate is: $%.4f/KwH\n", rate);
            System.out.printf("Your subtotal was: $%.2f\n", subtotal);
            System.out.printf("The taxes come to: $%.2f\n", taxOwed);
            System.out.printf("The total bill is: $%.2f\n", taxOwed + subtotal);

            /* Check if user wants to try again */
            while (true) {
                System.out.print("Would you like to calculate a new total? (Y for "
                        + "Yes, N to exit) ");
                try {
                    /* This picks the first letter of the response */
                    cont = INPUT.next().charAt(0);
                } catch (InputMismatchException e) {
                    INPUT.nextLine();  // clears INPUT buffer
                    continue;          // skips the String validation
                }
                if (String.valueOf(cont).equalsIgnoreCase("n")) {
                    System.out.println("Goodbye!");
                    System.exit(0);
                    break;
                } else if (String.valueOf(cont).equalsIgnoreCase("y")) {
                    break;
                } else {
                    System.out.println("Invalid option");
                }
            }
        }
    }  //End Main Method

    /**
     * GetUsage just finds the difference between the two months' usages.
     * @param lastMonth
     * @param currentMonth
     * @return 
     */
    private static double getUsage(double lastMonth, double currentMonth) {
        return currentMonth - lastMonth;
    }

    /**
     * GetSubtotal calculates the usage times the rate to find a subtotal.
     * @param usage
     * @return 
     */
    private static double getSubtotal(double usage, double rate) {
        return usage * rate;
    }

    /**
     * returns the tax owed
     * @param subtotal
     * @return 
     */
    private static double getTax(double subtotal, double TAX) {
        return subtotal * TAX;
    }

}  //End Class Jdehay_6

