package week6_Skeleton;

/**
 * @Course: SDEV 250 ~ Java Programming I
 * @Author Name:
 * @Assignment Name:
 * @Date: Oct 17, 2016
 * @Description:
 */
//Imports
import java.util.Scanner;
//Begin Class Week6_Skeleton

public class Week6_Skeleton {

    //Begin Main Method
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        //Variable for do loop response
        String ans = "";

        /**
         * Other variables would be best defined here. Rates and the tax are set
         * values so they should be final. Placing those at the top would allow
         * easy changes if rates and taxes were to ever change.
         */
        System.out.println("Welcome to the City Power Bill calculator! ");

        //Begin loop
        do {
            System.out.print("Please enter your previous meter reading: ");
            double previousReading = sc.nextDouble();
            System.out.print("Please enter your current meter reading: ");
            double currentReading = sc.nextDouble();

            /**
             * Assign a variable to the method call and send the two variables
             * that were just input from the user.
             */
            double usage = MyUsage(previousReading, currentReading); //See method MyUsage below

            /**
             * Now that we have the variable usage defined with the method
             * call and the variables have been sent to the method, the variable 
             * usage will now be set equal to the result returned from the method.
             * next line of code should be moved to the output statements below.
             * This was just to show you how the method produces the correct
             * result.
             */
            
            /**
             * Assign the rates defined in variables above with a series of if &
             * else/if statements.
             */
            
            /**
             * Now that you have usage and the rate assigned, call a method
             * SubTot to determine subtotal Assign a variable to the method call
             * similar to the way usage was above. Send usage & rate to the
             * method
             */
            
            /**
             * Next, call a method to determine tax based on SubTot. Assign a
             * variable to the method call similar to the way usage was above.
             * Send subTot & the variable that you will define up-top for the tax
             * rate to the method
             */
            
            /**
             * Now that you have the subtotal and tax amount, you can use those
             * to determine final total. This can be one line of code and does
             * not have to be a method call.
             */
            
            /**
             * Now you can do the outputs to output all of the results "Your
             * usage was:" "Your rate was:" "Your subtotal is:" "Taxes are:"
             * "Your total bill this month is:" The first one is below.
             */
            System.out.printf("The usage was: %.2f\n", usage);
            //Other required outputs here

            //Exit the program?
            System.out.print("Would you like to run the program again? (Y for Yes, N for No): ");
            ans = sc.next();
            
            //End loop   
        } while (ans.equalsIgnoreCase("y")); //Ignores case (upper or lower)
        System.out.println("Thank you for using the program\nGoodbye.");
    }//End Main Method

    /**Below is a proper method header above the method. To have NetBeans do this
     * for you, write the method. Then, place your cursor above the p in private
     * and hit enter. The compiler will add most of the header for you. Then you 
     * can edit the header to look like the one below.
     */
    
    
/**
 * Method MyUsage: Determine the power usage.
 *
 * @param prev
 * @param curr
 * @return customer usage
 */
private static double MyUsage(double prev, double curr) {
    return curr - prev; //SMH Return the difference.
}
}//End Class Week6_Skeleton
