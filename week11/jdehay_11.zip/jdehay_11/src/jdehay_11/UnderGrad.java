package jdehay_11;

/**
 * @Course: SDEV 250 ~ Java Programming I
 * @Author Name: Jeremy DeHay
 * @Assignment Name: jdehay_11
 * @Date: Nov 30, 2017
 * @Subclass UnderGrad Description: Subclass of Student with data specific to
 * the requirements of an undergrad student, such as the weight of each type of
 * grade and how the total is calculated
 */
//Imports
//Begin Subclass UnderGrad
public class UnderGrad extends Student {

    /**
     * Initializes the student with the appropriate weights for the assignments
     */
    UnderGrad() {
        percentAssignment = .65;
        percentDiscussion = .25;
        percentMidweekAssignment = .10;
    }

    /**
     * Tallies the applicable total of the weighted assignments and finishes by
     * calling the tallyTotal method from the Student class.
     */
    @Override
    protected void tallyTotal() {
        averageFinal += averageAssignments * percentAssignment;
        averageFinal += averageDiscussions * percentDiscussion;
        averageFinal += averageMidweekAssignments * percentMidweekAssignment;
        super.tallyTotal();
    }

} // End Subclass UnderGrad

/*
 (                         *     
 )\ )                    (  `    
(()/(  (   (   (  (  (   )\))(   
 /(_)) )\  )\  )\ )\ )\ ((_)()\  
(_))_ ((_)((_)((_|(_|(_)(_()((_) 
 |   \| __\ \ / / | | __|  \/  | 
 | |) | _| \ V / || | _|| |\/| | 
 |___/|___| \_/ \__/|___|_|  |_| 
      https://is.gd/RGR0UQ                  
*/
