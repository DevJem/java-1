package jdehay_11;

/**
 * @Course: SDEV 250 ~ Java Programming I
 * @Author Name: Jeremy DeHay
 * @Assignment Name: jdehay_11
 * @Date: Nov 30, 2017
 * @Description:
 */
//Imports
import java.util.InputMismatchException;
import java.util.Scanner;

//Begin Class Jdehay_11
public class Jdehay_11 {

    //Begin Main Method
    public static void main(String[] args) {

        // scanner object
        Scanner input = new Scanner(System.in);

        // declarations
        String firstName;
        String lastName;
        String answer;
        int studentType = 0;
        Student student;  // new student object

        while (true) {  // keep going?

            System.out.print("Enter your first name: ");
            firstName = input.nextLine();

            System.out.print("Enter your last name: ");
            lastName = input.nextLine();

            // determine student type
            while (true) {
                System.out.printf("Select %s %s's student type:\n", firstName,
                        lastName);
                System.out.println("1. Under Graduate Student");
                System.out.println("2. Graduate Student");
                System.out.print("->: ");
                try {
                    studentType = input.nextInt();
                } catch (InputMismatchException e) {
                    input.nextLine();
                    System.err.println("Please enter 1 or 2.");
                }
                if (studentType == 1 || studentType == 2) {
                    break;
                } else {
                    System.err.println("Please choose 1 or 2.");
                }
            }  // loop for student type

            // initialize specific student subclass
            if (studentType == 1) {
                student = new UnderGrad();
            } else {
                student = new Grad();
            }

            // Method calls to handle user input and number crunching
            student.setNames(firstName, lastName);
            student.setGrades();
            student.calculateAverages();
            student.tallyTotal();

            // Try again?
            System.out.printf("Would you like to run another calculation? (Y "
                    + "for yes, N for no): ", firstName, lastName);
            try {
                answer = input.next();
            } catch (InputMismatchException e) {
                input.nextLine();
                System.err.println("Input error.");
                answer = "n";
            }
            if (answer.equalsIgnoreCase("y")) {
                input.nextLine();
                continue;
            }
            break;

        }  // loop for rerunning program
    }  //End Main Method
}  //End Class Jdehay_11

/*
 (                         *     
 )\ )                    (  `    
(()/(  (   (   (  (  (   )\))(   
 /(_)) )\  )\  )\ )\ )\ ((_)()\  
(_))_ ((_)((_)((_|(_|(_)(_()((_) 
 |   \| __\ \ / / | | __|  \/  | 
 | |) | _| \ V / || | _|| |\/| | 
 |___/|___| \_/ \__/|___|_|  |_| 
      https://is.gd/RGR0UQ                  
 */
