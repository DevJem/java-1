package jdehay_11;

/**
 * @Course: SDEV 250 ~ Java Programming I
 * @Author Name: Jeremy DeHay
 * @Assignment Name: jdehay_11
 * @Date: Nov 30, 2017
 * @Subclass Grad Description: Subclass of Student with data specific to the
 * requirements of a grad student, such as the weight of each type of grade and
 * how the total is calculated
 */
//Imports
//Begin Subclass Grad
public class Grad extends Student {

    /**
     * Initializes the student with the appropriate weights for the assignments
     */
    public Grad() {
        percentAssignment = .40;
        percentDiscussion = .15;
        percentMidweekAssignment = .15;
        percentThesis = .30;
    }

    /**
     * Tallies the applicable total of the weighted assignments and finishes by
     * calling the tallyTotal method from the Student class.
     */
    @Override
    protected void tallyTotal() {
        System.out.printf("Enter the final Thesis grade for %s %s: ", firstName,
                lastName);
        gradeThesis = input.nextDouble();

        averageFinal += averageAssignments * percentAssignment;
        averageFinal += averageDiscussions * percentDiscussion;
        averageFinal += averageMidweekAssignments * percentMidweekAssignment;
        averageFinal += gradeThesis * percentThesis;

        super.tallyTotal();
    }

} // End Subclass Grad

/*
 (                         *     
 )\ )                    (  `    
(()/(  (   (   (  (  (   )\))(   
 /(_)) )\  )\  )\ )\ )\ ((_)()\  
(_))_ ((_)((_)((_|(_|(_)(_()((_) 
 |   \| __\ \ / / | | __|  \/  | 
 | |) | _| \ V / || | _|| |\/| | 
 |___/|___| \_/ \__/|___|_|  |_| 
      https://is.gd/RGR0UQ                  
*/
