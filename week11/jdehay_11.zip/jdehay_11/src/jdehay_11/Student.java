package jdehay_11;

/**
 * @Course: SDEV 250 ~ Java Programming I
 * @Author Name: Jeremy DeHay
 * @Assignment Name: jdehay_11
 * @Date: Nov 30, 2017
 * @Subclass Student Description: Superclass that defines the default variables
 *          and behavior of the subclasses Grad and Undergrad.
 */
//Imports
import java.util.InputMismatchException;
import java.util.Scanner;

//Begin Subclass Student
public class Student {

    // new scanner object
    Scanner input = new Scanner(System.in);

    // declarations
    protected String firstName;
    protected String lastName;
    protected int numAssignments;
    protected int numDiscussions;
    protected int numMidweekAssignments;
    protected boolean ideaSurvey;
    protected double percentAssignment;
    protected double percentDiscussion;
    protected double percentMidweekAssignment;
    protected double percentThesis;
    protected double[] gradesAssignment;
    protected double[] gradesDiscussion;
    protected double[] gradesMidweekAssignment;
    protected double gradeThesis;
    protected double averageFinal = 0;
    protected double averageAssignments;
    protected double averageDiscussions;
    protected double averageMidweekAssignments;

    
    public void setNames(String f, String l) {
        firstName = f;
        lastName = l;
    }

    /**
     * Public method called to retrieve user input.
     */
    public void setGrades() {
        setNumAssignments();
        setNumDiscussions();
        setNumMidweekAssignments();
    }

    /**
     * The following methods receive the number of each assignment type
     * completed and create the proper sized arrays for them, then pass that
     * data into the method that allows the user to populate that array
     */
    protected void setNumAssignments() {
        System.out.print("Enter the number of Assignment grades: ");
        numAssignments = input.nextInt();
        gradesAssignment = new double[numAssignments];
        enterGrades("Assignment", gradesAssignment);
    }

    protected void setNumDiscussions() {
        System.out.print("Enter the number of Discussion grades: ");
        numDiscussions = input.nextInt();
        gradesDiscussion = new double[numDiscussions];
        enterGrades("Discussion", gradesDiscussion);
    }

    protected void setNumMidweekAssignments() {
        System.out.print("Enter the number of Midweek Assignment grades: ");
        numMidweekAssignments = input.nextInt();
        gradesMidweekAssignment = new double[numMidweekAssignments];
        enterGrades("Midweek Assignment", gradesMidweekAssignment);
    }

    /**
     * This method allows the user to enter grades regardless of their type
     *
     * @param num
     * @param type
     */
    private void enterGrades(String type, double[] grade) {
        for (int i = 0; i < grade.length; i++) {
            System.out.printf("Enter %s grade number %d: ", type, i + 1);
            try {
                grade[i] = input.nextDouble();
            } catch (InputMismatchException e) {
                input.nextLine();
                System.err.println("Input error, try again.");
                i--;  // retry the entry
            }
        }
    }

    /**
     * Public method called to crunch the numbers
     */
    public void calculateAverages() {
        averageAssignments();
        averageDiscussions();
        averageMidweekAssignments();
    }

    /**
     * Calculate average of assignment grades
     */
    private void averageAssignments() {
        double total = 0f;
        for (int i = 0; i < numAssignments; i++) {
            total += gradesAssignment[i];
        }
        averageAssignments = total / numAssignments;
    }

    /**
     * Calculate average of discussion grades
     */
    private void averageDiscussions() {
        double total = 0;
        for (int i = 0; i < numDiscussions; i++) {
            total += gradesDiscussion[i];
        }
        averageDiscussions = total / numDiscussions;
    }

    /**
     * Calculate average of midweek assignment grades
     */
    private void averageMidweekAssignments() {
        double total = 0;
        for (int i = 0; i < numMidweekAssignments; i++) {
            total += gradesMidweekAssignment[i];
        }
        averageMidweekAssignments = total / numMidweekAssignments;
    }

    /**
     * Lets the tally method add one point to the final average if the survey
     * was completed
     *
     * @return
     */
    protected boolean ideaSurvey() {
        String answer;
        System.out.printf("Did %s %s fill out the IDEA survey? (Y for yes, N "
                + "for no): ", firstName, lastName);
        try {
            answer = input.next();
        } catch (InputMismatchException e) {
            input.nextLine();
            System.err.println("Input error.");
            answer = "n";
        }
        if (answer.equalsIgnoreCase("Y")) {
            return true;
        } else {
            return false;
        }
    }

    /**
     * Overridden method from the subclasses that also call this method to tally
     * the total of all grades based on their weighted averages.
     */
    protected void tallyTotal() {
        if (ideaSurvey()) {
            averageFinal += 1;
        }
        System.out.printf("%s %s's final grade average is: %.2f\n\n", firstName,
                lastName, averageFinal);
    }

} // End Subclass Student

/*
 (                         *     
 )\ )                    (  `    
(()/(  (   (   (  (  (   )\))(   
 /(_)) )\  )\  )\ )\ )\ ((_)()\  
(_))_ ((_)((_)((_|(_|(_)(_()((_) 
 |   \| __\ \ / / | | __|  \/  | 
 | |) | _| \ V / || | _|| |\/| | 
 |___/|___| \_/ \__/|___|_|  |_| 
      https://is.gd/RGR0UQ                  
 */
