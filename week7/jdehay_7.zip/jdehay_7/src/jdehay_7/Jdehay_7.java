package jdehay_7;

/**
 * @Course: SDEV 250 ~ Java Programming I
 * @Author Name: Jeremy DeHay
 * @Assignment Name: jdehay_7
 * @Date: Oct 21, 2017
 * @Description: This program accepts a number of grades then prints each
 * grade's letter grade as well as the high, low, and average of the grades
 * entered.
 */
//Imports
import java.util.Random;
import java.util.Scanner;

//Begin Class Jdehay_7
public class Jdehay_7 {

    //Begin Main Method
    public static void main(String[] args) {

        /* Variables */
        final Scanner INPUT = new Scanner(System.in);
        final int MAX = 100;
        final int MIN = 55;
        int numGrades = 0;
        double lowGrade;
        double highGrade;
        double average;
        String again = "";

        /* Loop to keep program running until user exits */
        while (true) {
            /* Find number of grades to randomly generate */
            while (true) {
                System.out.print("How many grades would you like to enter? (1-99) ");

                try {
                    numGrades = INPUT.nextInt();
                } catch (Exception e) {
                    System.out.println("Input error, please try again.");
                    INPUT.nextLine();
                }
                if (numGrades > 0 && numGrades < 100) {
                    break;
                } else {
                    System.out.println("Enter a number between 1 and 99.");
                }
            }

            /* Dynamically allocated array */
            double[] gradeArray = new double[numGrades];

            /* Populate array and calculate results */
            gradeArray = randomGrades(gradeArray, MAX, MIN);
            gradeOutput(gradeArray);
            lowGrade = findLow(gradeArray);
            highGrade = findHigh(gradeArray);
            average = findAverage(gradeArray);

            /* Display results */
            System.out.printf("The lowest grade was: %.2f\n", lowGrade);
            System.out.printf("The highest grade was: %.2f\n", highGrade);
            System.out.printf("The average is: %.2f\n", average);
            
            
            /**
             * Check to see if the program should run again.
             */
            while (true) {
                System.out.println("Would you like to run the program again? (Y"
                        + " for yes, N for no)");
                try {
                    again = INPUT.next();
                } catch (Exception e) {
                    System.out.println("Input error, please try again.");
                }
                if (again.equalsIgnoreCase("y")) {
                    break;
                } else if (again.equalsIgnoreCase("n")) {
                    System.out.println("Goodbye!");
                    System.exit(0);
                } else {
                    System.out.println("Please enter Y or N");
                }
            }
        }

    }  //End Main Method

    /**
     * This method generates a random number between the min and max variables
     * provided and places one into each element in the grade array. The source
     * for the random number within the range was sourced from StackOverflow.
     * https://stackoverflow.com/a/9723994/4196281
     *
     * @param gradeArray
     * @param max
     * @param min
     */
    private static double[] randomGrades(double[] gradeArray, int max, int min) {
        Random random = new Random();
        for (int i = 0; i < gradeArray.length; i++) {
            gradeArray[i] = random.nextDouble() * (max - min) + min;
        }
        return gradeArray;
    }

    /**
     * Define letter grade and format output
     * @param gradeArray 
     */
    private static void gradeOutput(double[] gradeArray) {
        String grade;
        System.out.println("The letter grades for each score are:");
        for (int i = 0; i < gradeArray.length; i++) {
            grade = "";
            if (gradeArray[i] >= 92.5) {
                grade = "A";
            } else if (gradeArray[i] >= 89.5) {
                grade = "A-";
            } else if (gradeArray[i] >= 86.5) {
                grade = "B+";
            } else if (gradeArray[i] >= 82.5) {
                grade = "B";
            } else if (gradeArray[i] >= 79.5) {
                grade = "B-";
            } else if (gradeArray[i] >= 76.5) {
                grade = "C+";
            } else if (gradeArray[i] >= 72.5) {
                grade = "C";
            } else if (gradeArray[i] >= 69.5) {
                grade = "C-";
            } else if (gradeArray[i] >= 66.5) {
                grade = "D+";
            } else if (gradeArray[i] >= 62.5) {
                grade = "D";
            } else if (gradeArray[i] >= 60) {
                grade = "D-";
            } else {
                grade = "F";
            }
            System.out.printf("Grade %d: %.2f is a %s\n", i + 1, gradeArray[i],
                    grade);
        }
    }

    /**
     * Find lowest grade
     * @param gradeArray
     * @return 
     */
    private static double findLow(double[] gradeArray) {
        double low = gradeArray[0];
        for (int i = 1; i < gradeArray.length; i++) {
            if (gradeArray[i] < low) {
                low = gradeArray[i];
            }
        }
        return low;
    }

    /**
     * Find highest grade
     * @param gradeArray
     * @return 
     */
    private static double findHigh(double[] gradeArray) {
        double high = gradeArray[0];
        for (int i = 1; i < gradeArray.length; i++) {
            if (gradeArray[i] > high) {
                high = gradeArray[i];
            }
        }
        return high;
    }

    /**
     * Find average of grades
     * @param gradeArray
     * @return 
     */
    private static double findAverage(double[] gradeArray) {
        double total = 0;
        for (int i = 0; i < gradeArray.length; i++) {
            total += gradeArray[i];
        }
        return total / gradeArray.length;
    }

}  //End Class Jdehay_7

/*
 (                         *     
 )\ )                    (  `    
(()/(  (   (   (  (  (   )\))(   
 /(_)) )\  )\  )\ )\ )\ ((_)()\  
(_))_ ((_)((_)((_|(_|(_)(_()((_) 
 |   \| __\ \ / / | | __|  \/  | 
 | |) | _| \ V / || | _|| |\/| | 
 |___/|___| \_/ \__/|___|_|  |_| 
       https://is.gd/RGR0UQ                  
*/
