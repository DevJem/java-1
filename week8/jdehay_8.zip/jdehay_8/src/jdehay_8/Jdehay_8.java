package jdehay_8;

/**
  *  @Course: SDEV 250 ~ Java Programming I
  *  @Author Name: Jeremy DeHay
  *  @Assignment Name: jdehay_8
  *  @Date: Oct 23, 2017
  *  @Description: This program asks the user to define a square matrix, take 
  *                user input to fill out the matrix with integers, then 
  *                calculates the sum of each column and each row, the product
  *                of each column and row, and find the greatest and least
  *                values in the matrix.
  */

//Imports
import java.util.Scanner;

//Begin Class Jdehay_8
public class Jdehay_8 {

    //Begin Main Method
    public static void main(String[] args) {
        
        /* Variables */
        final Scanner INPUT = new Scanner(System.in);
        int nums = 0;
        String again = "";

        /* Introduces the program */
        System.out.println("Welcome! This program that accepts an n x n matrix,"
                + " totals the rows and columns & finds the product of each row"
                + " and column.\n\n");
        
        /* Loop to continue program */
        while (true) {
            
            /* Retrieves and validates the number of rows and colums */
            while (true) {
                System.out.print("Enter number of rows & columns (they will be "
                        + "the same): ");
                try { 
                    nums = INPUT.nextInt();
                } catch (Exception e) {
                    INPUT.nextLine();
                    System.out.println("Input error, try again.");
                }
                if (nums > 0) {
                    break;
                } else {
                    System.out.println("Please enter a positive, whole number.");
                }
            }

            /* Builds the empty grid */
            int[][] grid = new int[nums][nums];

            /* Populates the matrix one number at a time while validating input */
            for (int i = 0; i < nums; i++) {
                for (int j = 0; j < nums; j++) {
                    while (true) {
                        System.out.printf("Enter a value for Row %d, Column %d: ", 
                                i + 1, j + 1 );
                        try {
                            grid[i][j] = INPUT.nextInt();
                        } catch (Exception e) {
                            INPUT.nextLine();
                            System.out.println("Input error, try again.");
                        }
                        if (grid[i][j] > 0) {
                            break;
                        } else {
                            System.out.println("Please enter a positive, whole "
                                    + "number.");
                        }
                    }                
                }
            }

            /* Calls the calculation methods and formats output */
            System.out.println("\nThe Matrix****************************************");
            displayGrid(grid, nums);
            System.out.println("\nRow Totals****************************************");
            sumRows(grid, nums);
            System.out.println("\nColumn Totals*************************************");
            sumColumns(grid, nums);
            System.out.println("\nRow Products*************************************");
            rowProducts(grid, nums);
            System.out.println("\nColumn Products*************************************");
            columnProducts(grid, nums);

            System.out.printf("\nThe greatest value in this matrix is: %d\n",
                    greatest(grid, nums));
            System.out.printf("\nThe lowest value in this matrix is: %d\n", 
                    lowest(grid, nums));
            
            /**
             * Check to see if the program should run again.
             */
            while (true) {
                System.out.println("Enter another matrix? (Y for yes, N for no)");
                try {
                    again = INPUT.next();
                } catch (Exception e) {
                    System.out.println("Input error, please try again.");
                }
                if (again.equalsIgnoreCase("y")) {
                    break;
                } else if (again.equalsIgnoreCase("n")) {
                    System.out.println("Goodbye!");
                    System.exit(0);
                } else {
                    System.out.println("Please enter Y or N");
                }
            }
        }
        
    }  //End Main Method

    /**
     * Displays the entries in matrix format
     * @param grid
     * @param nums 
     */
    private static void displayGrid(int[][] grid, int nums) {
        System.out.println("You entered the following matrix:");
        for (int i = 0; i < nums; i ++) {
            for (int j = 0; j < nums; j++) {
                System.out.printf("\t%d", grid[i][j]);
            }
            System.out.print("\n");
        }
    }

    /**
     * Prints the sum of each row
     * @param grid
     * @param nums 
     */
    private static void sumRows(int[][] grid, int nums) {
        for (int i = 0; i < nums; i ++) {
            int sum = 0;
            for (int j = 0; j < nums; j++) {
                sum += grid[i][j];
            }
            System.out.printf("The sum of row %d is: %d\n", i + 1, sum);
        }
    }

    /**
     * Prints the sum of each column
     * @param grid
     * @param nums 
     */
    private static void sumColumns(int[][] grid, int nums) {
        for (int i = 0; i < nums; i ++) {
            int sum = 0;
            for (int j = 0; j < nums; j++) {
                sum += grid[j][i];
            }
            System.out.printf("The sum of column %d is: %d\n", i + 1, sum);
        }
    }

    /**
     * Prints the product of each row
     * @param grid
     * @param nums 
     */
    private static void rowProducts(int[][] grid, int nums) {
        for (int i = 0; i < nums; i ++) {
            int product = 1;
            for (int j = 0; j < nums; j++) {
                product *= grid[i][j];
            }
            System.out.printf("The prodcut of row %d is: %d\n", i + 1, product);
        }
    }

    /**
     * Prints the product of each column
     * @param grid
     * @param nums 
     */
    private static void columnProducts(int[][] grid, int nums) {
        for (int i = 0; i < nums; i ++) {
            int product = 1;
            for (int j = 0; j < nums; j++) {
                product *= grid[j][i];
            }
            System.out.printf("The product of column %d is: %d\n", i + 1, product);
        }
    }

    /**
     * Finds the highest user-entered value in the matrix
     * @param grid
     * @param nums
     * @return largest value
     */
    private static int greatest(int[][] grid, int nums) {
        int greatest = grid[0][0];
        for (int i = 0; i < nums; i ++) {
            for (int j = 0; j < nums; j++) {
                if (grid[i][j] > greatest) {
                    greatest = grid[i][j];
                }
            }
        }
        return greatest;
    }

    /**
     * Finds the lowest user-entered value in the matrix
     * @param grid
     * @param nums
     * @return least value 
     */
    private static int lowest(int[][] grid, int nums) {
        int least = grid[0][0];
        for (int i = 0; i < nums; i ++) {
            for (int j = 0; j < nums; j++) {
                if (grid[i][j] < least) {
                    least = grid[i][j];
                }
            }
        }
        return least;
    }
}  //End Class Jdehay_8

/*
 (                         *     
 )\ )                    (  `    
(()/(  (   (   (  (  (   )\))(   
 /(_)) )\  )\  )\ )\ )\ ((_)()\  
(_))_ ((_)((_)((_|(_|(_)(_()((_) 
 |   \| __\ \ / / | | __|  \/  | 
 | |) | _| \ V / || | _|| |\/| | 
 |___/|___| \_/ \__/|___|_|  |_| 
      https://is.gd/RGR0UQ                  
*/