package jdehay_4;

import java.util.Scanner;

/**
  *  @Course: SDEV 250 ~ Java Programming I
  *  @Author Name: Jeremy DeHay
  *  @Assignment Name: jdehay_4
  *  @Date: Sep 23, 2017
  *  @Description: This program accepts a paragraph of text, manipulates it,
  *                and outputs the manipulated text to the console.
  */
//Imports

//Begin Class Jdehay_4
public class Jdehay_4 {
    
    /* Global input scanner to accept input from the user */
    private static final Scanner INPUT = new Scanner(System.in);

    //Begin Main Method
    public static void main(String[] args) {
        
        /* Assign the entered paragraph returned from getParagraph() */
        String paragraph = getParagraph();
        
        /* Display the entered paragraph */
        System.out.printf("The paragraph you entered is:\n\n\"%s\"\n", paragraph);
        
        /**
         * This block keeps the menu up until the user chooses to exit it.
         * The try/catch block ensures that the program will continue even
         * if the user encounters problems with their entry.
         */
        while (true) {
            try {
                /* Pass the selected menu option to the results switch */
                menuResult(menuOptions(), paragraph);
            } catch (Exception e) {
                System.out.println("Invalid entry, try again.");
            }
        }
    }  //End Main Method
    
    /**
     * Retrieves the paragraph input and returns it to main
     * @return paragraph
     */
    private static String getParagraph() {
        System.out.println("Enter a paragraph:");
        return INPUT.nextLine();
    }
    
    /**
     * Output the menu and return the option chosen by the user
     * @return menu item
     */
    private static String menuOptions() {
        
        System.out.println("\nPlease choose from the following menu of options");
        System.out.println("1) Convert to all uppercase letters.");
        System.out.println("2) Convert to all lowercase letters.");
        System.out.println("3) Display the length of the paragraph.");
        System.out.println("4) Select a substring from the paragraph.");
        System.out.println("5) Let Random select a substring from the paragraph.");
        System.out.println("6) Exit.");
        
        return INPUT.next();
    }
    
    /**
     * Switch/case to perform the menu action selected. Also recieves the 
     * paragraph to manipulate and display it.
     * @param result
     * @param paragraph 
     */
    private static void menuResult(String result, String paragraph) {
        switch (result) {
            case "1": 
                System.out.printf("Here is your paragraph in uppercase letters: "
                        + "%s\n", paragraph.toUpperCase());
                break;
            case "2": 
                System.out.printf("Here is your paragraph in lowercase letters: "
                        + "%s\n", paragraph.toLowerCase());
                break;
            case "3": 
                System.out.printf("The length of your paragraph is: %s characters "
                        + "and spaces.\n", paragraph.length());
                break;
            case "4": 
                /* Method to allow the user to select the substring */
                userSelectedSubstring(paragraph);
                break;
            case "5":
                /* Method to randomly select the substring */
                randomSelectedSubstring(paragraph);
                break;
            case "6":
                System.out.println("Goodbye!");
                System.exit(0);
            default: 
                System.out.println("It appears you have made an invalid choice.");
                break;
        }
    }

    /**
     * Allows the user to select two points within the paragraph to pull the
     * range from. Uses input validation to ensure the user does not use a 
     * value outside the range of the paragraph.
     * @param paragraph 
     */
    private static void userSelectedSubstring(String paragraph) {
        int start;
        int end;
        int length = paragraph.length();
        
        /* Validated input to start the substring */
        while (true) {
            System.out.printf("Select a starting point (Range is 0 to %s): ", 
                    length);
            start = INPUT.nextInt();
            if (start < length && start >= 0 ) {
                break;
            } else {
                System.out.println("Invalid number.");
            }
        }
        
        /* Validated input to end the substring */
        while (true) {
            System.out.printf("Select an ending point (Range is %d to %s): ", 
                start + 1, length);
            end = INPUT.nextInt();
            if (end <= length && end > start ) {
                break;
            } else {
                System.out.println("Invalid number.");
            }
        }
        System.out.printf("Your substring starting at %d and ending at %d is: %s\n", 
                start, end, paragraph.substring(start, end));
    }

    /**
     * This method figures out two points within the range of the paragraph
     * string and creates a substring out of them.
     * @param paragraph 
     */
    private static void randomSelectedSubstring(String paragraph) {
        int length = paragraph.length();
        
        /* Random starting point */
        int start = (int) (Math.random() * length); 
        
        /* Random ending point */
        int end = (int) (start + Math.random() * (length - start)) + 1;
        
        System.out.printf("The randomly generated substring starting at %d and "
                + "ending at %d is: %s\n", start, end, paragraph.substring(start, end));
    }

}  //End Class Jdehay_4