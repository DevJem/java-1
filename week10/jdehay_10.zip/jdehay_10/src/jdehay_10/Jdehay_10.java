package jdehay_10;

/**
  *  @Course: SDEV 250 ~ Java Programming I
  *  @Author Name: Jeremy DeHay
  *  @Assignment Name: jdehay_10
  *  @Date: Nov 13, 2017
  *  @Description: This program allows the user to enter their credit card 
  *             information including name, card number, and experation date.
  *             It passes the number and exp date to another class to verify
  *             the information and returns whether or not the entry is valid.
  */

//Imports
import java.util.InputMismatchException;
import java.util.Scanner;


//Begin Class Jdehay_10
public class Jdehay_10 {

    //Begin Main Method
    public static void main(String[] args) {
        
        // variables
        Scanner input = new Scanner(System.in);
        String name;
        String number;
        String expDate;
        char cont;
        String result;
        
        while (true) {  // Start program loop
            
            // Get and validate name pattern
            while (true) {
                System.out.print("Enter Card Holder's Name: ");
                try {
                    name = input.nextLine();
                    // regex requires only letters on the line
                    if (name.matches("^[a-zA-Z\\s]+$")) {  // https://is.gd/b3b66r
                        break;
                    } else {
                        System.err.println("Names may only contain letters.");
                    }
                } catch (Exception e) {
                    input.nextLine();
                    System.err.println("Input error, try again." + e);
                }
            }  // End name entry
            
            // Get and validate card number pattern
            while (true) {
                System.out.print("Enter Card Number (No dashes or spaces): ");
                try {
                    number = input.next();
                    // regex requires "xxxx-xxxx-xxxx-xxxx" or "xxxxxxxxxxxxxxxx"
                    if (number.matches("\\d{4}-\\d{4}-\\d{4}-\\d{4}") || 
                            number.matches("\\d{16}")) {
                        break;
                    } else {
                        System.err.println("Invalid card number, please try again.");
                    }
                } catch (Exception e) {
                    input.nextLine();
                    System.err.println("Input error, try again.\n" + e);
                }
            }  // End card number
            
            // Get and validate exp date pattern
            while (true) {
                System.out.print("Enter Card's Experation Date (MM/YY): ");
                try {
                    expDate = input.next();
                    // regex requires "xx/xx"
                    if (expDate.matches("\\d{2}/\\d{2}")) {
                        break;
                    } else {
                        System.err.println("Invalid experation date, please try"
                                + " again.");
                    }
                } catch (Exception e) {
                    input.nextLine();
                    System.err.println("Input error, try again.\n" + e);
                }
            }  // End exp Date
            
            CardVerification verifier = new CardVerification(number, expDate);
            result = verifier.getResult() ? "is" : "is NOT";
            
            System.out.printf("Card number: %s %s a valid credit card.\n", 
                    number, result);
            
             /* Check if user wants to try again */
            while (true) {
                System.out.print("Would you like to try again? (Y for Yes, N "
                        + "to exit) ");
                try {
                    /* This picks the first letter of the response */
                    cont = input.next().charAt(0);
                } catch (InputMismatchException e) {
                    input.nextLine();  // clears input buffer
                    continue;          // skips the String validation
                }
                if (String.valueOf(cont).equalsIgnoreCase("n")) {
                    System.out.println("Goodbye!");
                    System.exit(0);
                    break;
                } else if (String.valueOf(cont).equalsIgnoreCase("y")) {
                    input.nextLine();
                    break;
                } else {
                    System.err.println("Invalid option");
                }
            }  // End quit loop
        }  // End program loop
    }  //End Main Method    
}  //End Class Jdehay_10

/*
 (                         *     
 )\ )                    (  `    
(()/(  (   (   (  (  (   )\))(   
 /(_)) )\  )\  )\ )\ )\ ((_)()\  
(_))_ ((_)((_)((_|(_|(_)(_()((_) 
 |   \| __\ \ / / | | __|  \/  | 
 | |) | _| \ V / || | _|| |\/| | 
 |___/|___| \_/ \__/|___|_|  |_| 
      https://is.gd/RGR0UQ                  
*/