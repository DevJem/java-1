package jdehay_10;

/**
 * @Course: SDEV 250 ~ Java Programming I
 * @Author Name: Jeremy DeHay
 * @Assignment Name: jdehay_10
 * @Date: Nov 20, 2017
 * @Subclass CardVerification Description: This class does all of the secret
 * work behind verifying the credit card entry.
 */
//Imports
//import java.util.Calendar;

//Begin Subclass CardVerification
public class CardVerification {

    // variables
    private boolean result = false;
    private String number;
    private String expDate;
    private int lastTwoProduct;

    // constructor
    CardVerification(String number, String expDate) {
        setNumber(number);
        setExpDate(expDate);
    }

    public boolean getResult() {
        setResult();
        return result;
    }

    private void setNumber(String num) {
        number = num;
    }

    private void setExpDate(String date) {
        expDate = date;
    }

    private void setResult() {

        if (numberGood(number) && expDateGood(expDate)) {
            result = true;
        }
    }

    /**
     * numberGood checks the many constraints on the entered number to validate
     * it.
     *
     * @param number
     * @return
     */
    private boolean numberGood(String number) {
        String normalizedNum = number.replaceAll("-", "");
        int[] numAsInt = new int[normalizedNum.length()];

        // move string to int array
        for (int i = 0; i < normalizedNum.length(); i++) {
            numAsInt[i] = Character.getNumericValue(normalizedNum.charAt(i));
        }

        // first number must be a 4
        if (numAsInt[0] != 4) {
//            System.err.println("Card number should start with a 4");
            return false;
        }

        // Fourth digit must be one greater than the fifth digit
        if (numAsInt[3] != (numAsInt[4] + 1)) {
//            System.err.println("Fourth digit must be one greater than the "
//                    + "fifth digit");
            return false;
        }

        // Product of the first, fifth, and ninth digits must be 24
        if ((numAsInt[0] * numAsInt[4] * numAsInt[8]) != 24) {
//            System.err.println("Product of the first, fift, and ninth digits"
//                    + " must be 24.");
            return false;
        }

        // Sum of all digits must be divisible by 4
        if (!divByFour(numAsInt)) {
//            System.err.println("Sum of all digits must be divisible by 4");
            return false;
        }

        // Sum of the first four digits must be one less than the sum of the 
        // last four digits
        if (!sumCheck(numAsInt)) {
//            System.err.println("Sum of the first four digits must be one "
//                    + "less than the sum of the last four digits.");
            return false;
        }

        // First two digits and last two digits must add up to 100
        if (!sumOneHundred(numAsInt)) {
//            System.err.println("First two digits and last two digits must"
//                    + " add up to 100.");
            return false;
        }

        // Prep for exp date validation
        lastTwoProduct = numAsInt[numAsInt.length - 1] * 
                numAsInt[numAsInt.length - 2];

        return true;
    }

    private boolean expDateGood(String expDate) {
        String normalizedExpDate = expDate.replaceAll("/", "");
        int[] expDateAsInt = new int[normalizedExpDate.length()];

        // move string to int array
        for (int i = 0; i < normalizedExpDate.length(); i++) {
            expDateAsInt[i] = Character.getNumericValue(normalizedExpDate.charAt(i));
        }

        int sum = 0;
//        int year = Calendar.getInstance().get(Calendar.YEAR);
        String[] date = expDate.split("/");

        // The sum of the digits in the exp date must be less than the product
        // of the last two digits of the card number
        for (int i = 0; i < expDateAsInt.length; i++) {
            sum += expDateAsInt[i];
        }

        if (sum >= lastTwoProduct) {
//            System.err.println("Sum of digits in exp date must be less than "
//                    + "the product of the last two digits of the card number.");
            return false;
        }

        // month can't go above 12 and year cant be less than this year.
        if (Integer.parseInt(date[0]) > 12) {
//            System.err.println("Month cannot be larger than 12");
            return false;
        }

//        if ((Integer.parseInt(date[1]) + 2000) < year) {
////            System.err.println("Year must be at least " + year);
//            return false;
//        }
        return true;
    }

    /**
     * Method to validate card number is divisible by 4
     *
     * @param numAsInt
     * @return
     */
    private boolean divByFour(int[] numAsInt) {

        int total = 0;

        for (int i = 0; i < numAsInt.length; i++) {
            total += numAsInt[i];
        }

        if (total % 4 == 0) {
            return true;
        }
        return false;
    }

    /**
     * Method to validate the sum of the first four digits of the card number is
     * one less than the sum of the last four digits.
     *
     * @param numAsInt
     * @return
     */
    private boolean sumCheck(int[] numAsInt) {

        int firstFourSum = 0;
        int lastFourSum = 0;

        for (int i = 0; i < 4; i++) {
            firstFourSum += numAsInt[i];
        }

        for (int j = numAsInt.length - 1; j >= numAsInt.length - 4; j--) {
            lastFourSum += numAsInt[j];
        }

        if (firstFourSum == (lastFourSum - 1)) {
            return true;
        }

        return false;
    }

    /**
     * Method to validate the sum of the first two digits as a single number and
     * the last two digits as a single number is equal to one hundred
     *
     * @param numAsInt
     * @return
     */
    private boolean sumOneHundred(int[] numAsInt) {

        int firstTwo = (numAsInt[0] * 10) + numAsInt[1];
        int lastTwo = (numAsInt[14] * 10) + numAsInt[15];

        if (firstTwo + lastTwo == 100) {
            return true;
        }

        return false;
    }

} // End Subclass CardVerification

/*
 (                         *     
 )\ )                    (  `    
(()/(  (   (   (  (  (   )\))(   
 /(_)) )\  )\  )\ )\ )\ ((_)()\  
(_))_ ((_)((_)((_|(_|(_)(_()((_) 
 |   \| __\ \ / / | | __|  \/  | 
 | |) | _| \ V / || | _|| |\/| | 
 |___/|___| \_/ \__/|___|_|  |_| 
      https://is.gd/RGR0UQ                  
 */
