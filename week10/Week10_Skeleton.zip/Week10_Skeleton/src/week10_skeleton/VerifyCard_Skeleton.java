package week10_skeleton;

/**
 * @Course: SDEV 250 ~ Java Programming I
 * @Author Name: Steven Hickey
 * @Assignment Name: week10_skeleton
 * @Date: Nov 14, 2016 (Updated 4/10/2017)
 * @Subclass VerifyCard_Skeleton Description:
 */
//Imports
//Begin Subclass VerifyCard_Skeleton
public class VerifyCard_Skeleton {

    //Declarations
    private final int CHK_ONE = 1;
    private final int CHK_TWO = 24;
    private String name;
    private String card;
    private String date;
    private int[] cDate;
    private int first;
    private int fourth;
    private int fifth;
    private int ninth;
    private int allTot;
    private int dateTot;
    private int lastTwo = 1;
    private int firstFour;
    private int lastFour;
    private int firstTwo;
    private boolean allGood = true;
    private boolean goodCard = false;

    /**
     * Default constructor
     */
    VerifyCard_Skeleton() {
        this("No Entry", "No Entry", "No Entry");
    }

    /**
     * Constructor: Used to assign received values to private variable and to
     * call private method and send data
     *
     * @param aName
     * @param ccNum
     * @param aDate
     */
    VerifyCard_Skeleton(String aName, String ccNum, String aDate) {
        //Assign public data to private variables
        name = aName;
        card = ccNum;
        date = aDate;
        //Call method to set data, check card and date
        verifyInfo(name, card, date);
    }

    /**
     * Method used to set data and then call the verification process
     *
     * @param n
     * @param ccn
     * @param dt
     */
    private void verifyInfo(String n, String ccn, String dt) {
        //Set data
        setName(n);
        setCard(ccn);
        setDate(dt);
        //Call method to begin verification process
        checkCard();
    }

    /*Set Methods**************************************************************/
    /**
     * Set name method
     *
     * @param chName
     */
    private void setName(String chName) {
        name = chName;
    }

    /**
     * Set card number method
     *
     * @param cC
     */
    private void setCard(String cC) {
        card = cC;
    }

    /**
     * Set date.
     *
     * @param dT
     */
    private void setDate(String dT) {
        //Remove slash from date String with replaceAll
        
        //Create a new int array to store the date after it is converted
        
        //For loop used to convert String date to an int array
        for (int i = 0; i < dT.length(); i++) {
            //<Name given new int array>[i] = Integer.parseInt(dT.split("")[i]);
        }
        //cDate = <Name given new int array>;
    }
    
    /**
     * Method setVerify: set flag holder for card status
     * @param goodBad 
     */
    private void setVerify(boolean goodBad) {
        goodCard = goodBad;
    }
/*End Set Methods**********************************************************/

/*Get Methods**************************************************************/
    /**
     * Return name when called
     *
     * @return name
     */
    public String getName() {
        return name;
    }

    /**
     * Return card number when called
     *
     * @return card
     */
    public String getCard() {
        return card;
    }

    /**
     * Return date when called
     *
     * @return date
     */
    public String getDate() {
        return date;
    }
    
    /**
     * Method used to return the status of the card verification process.
     * Boolean value goodCard is used as a flag and set in the conditional
     * methods.
     *
     * @return goodCard
     */
    public boolean getVerify() {
        return goodCard;
    }
    
    /*End Get Methods**********************************************************/

    /**
     * Collect card number and send to verifier
     */
    private void checkCard() {
        verifyInfo(/*call get card method*/);
    }

    /**
     * Verify card number. Uses card number to verify the card through the
     * 7 check Conditions
     *
     * @param cardNum
     */
    private void verifyInfo(String cardNum) {

        /**
         * Create a new int array to store card number after it is converted
         */
        int[] /*name of card array*/ = new int[cardNum.length()];

        /**
         * For loop used to convert String card number to an int array
         */
        for (int i = 0; i < cardNum.length(); i++) {
            /*name of card array*/[i] = Integer.parseInt(cardNum.split("")[i]);
        }
        
        /**
         * Use regex to check first digit. If good, set verify card as true and then
         * call condition checker 2
         */
        //Condition 1.The first digit must be a 4.
        if (cardNum.matches(/*place regex expression here*/)) {
            //If condition 1 is good
            //set boolean allGood to true
            //send allGood to setVerify method
            //call condTwo method and send it the cardArray
        } else {
            //If condition 1 is bad
            //set boolean allGood to false
            //send allGood to setVerify method
        }
    }

    /**
     * Condition 2: The fourth digit must be one greater than the fifth digit.
     *
     * @param cArr
     */
    private void condTwo(/*receive int card array*/) {
        allGood = false;    //Reset boolean flag for each condition
        fourth = /*array element position*/; //Remember, array elements begin counting at zero
        fifth = /*array element position*/;

        if (fourth - fifth == CHK_ONE) {
            //If condition 2 is good
            //set boolean allGood to true
            //send allGood to setVerify method
            //call condThree method and send it the cardArray
        } else {
            //If condition 2 is bad
            //set boolean allGood to false
            //send allGood to setVerify method
        }
    }

    /**
     * Condition 3: The product of the first, fifth, and ninth digits must be
     * 24.
     *
     * @param iArr
     */
    private void condThree(/*receive int card array*/) {
        allGood = false;    //Reset boolean flag for each condition
        first = /*array element position*/;
        fifth = /*array element position*/;
        ninth = /*array element position*/;

        if (first * fifth * ninth == CHK_TWO) {
            //If condition 3 is good
            //set boolean allGood to true
            //send allGood to setVerify method
            //call condFour method and send it the cardArray
        } else {
            //If condition 3 is bad
            //set boolean allGood to false
            //send allGood to setVerify method
        }
    }

    /**
     * Condition 4: The sum of all digits must be evenly divisible by 4
     *
     * @param cardNum
     * @param cardArray
     */
    private void condFour(/*receive int card array*/) {
        allGood = false;    //Reset boolean flag for each condition

        /**
         * Create a for loop to loop through cardArray and add all digits together
         */
        //for loop here

        /**
         * If modulus of the total is 0, then the sum of the numbers is evenly
         * divided by 4. Use mod for this one.
         */
        if ((allTot % 4) == 0) {
            //If condition 4 is good
            //set boolean allGood to true
            //send allGood to setVerify method
            //call condFive method and send it the cardArray and cDate (array)
        } else {
            //If condition 4 is bad
            //set boolean allGood to false
            //send allGood to setVerify method
        }
    }

    /**
     * Condition 5: The sum of the four digits in the expiration date must be
     * less than the product of the last two digits of the card number.
     *
     * @param name given to card array
     * @param name given to date array
     */
    private void condFive(/*receive int card array, recieve date array*/) {
        allGood = false;    //Reset boolean flag for each condition

        /**
         * Create a for loop to loop through date and add all digits. Assign 
         * result to variable dateTot
         */
        //for loop here

        /**
         * Begin loop at end of cardArray and multiply the numbers from array
         * position 14 and 15
         */
        for (int i = /*name given to card array*/.length - 1; i >= /*name given to card array*/.length - 2; i--) {
            lastTwo *= /*name given to card array*/[i];
        }

        //Compare results
        if (lastTwo > dateTot) {
            //If condition 5 is good
            //set boolean allGood to true
            //send allGood to setVerify method
            //call condSix method and send it the cardArray
        } else {
            //If condition 5 is bad
            //set boolean allGood to false
            //send allGood to setVerify method
        }
    }

    /**
     * Condition 6: The sum of the first four digits must be one less than the
     * sum of the last four digits.
     *
     * @param name given to card array
     */
    private void condSix(/*receive int card array*/) {
        allGood = false;    //Reset boolean flag for each condition

        /**
         * Loop through cardArray's first 4 digits and add them together
         */
        for (int i = 0; i < 4; i++) {
            firstFour += /*name given to card array*/[i];
        }

        /**
         * Loop through cardArray's last 4 digits and add them together
         */
        for (int i = /*name given to card array*/.length - 1; i >= /*name given to card array*/.length - 4; i--) {
            lastFour += /*name given to card array*/[i];
        }

        //Compare results
        if (lastFour - firstFour == 1) {
            //If condition 6 is good
            //set boolean allGood to true
            //send allGood to setVerify method
            //call condSeven method and send it the cardArray
        } else {
            //If condition 6 is bad
            //set boolean allGood to false
            //send allGood to setVerify method
        }
    }

    /**
     * Condition 7: If you treat the first two digits as a two-digit number, and
     * the 15th and 16th digits as a two digit number, their sum must be 100.
     *
     * @param cardArray
     */
    private void condSeven(/*receive int card array*/) {
        allGood = false;    //Reset boolean flag for each condition
        lastTwo = 0;

        /**
         * Pull first two digits, convert to Strings, concate them, then convert
         * back to an integer value
         */
        firstTwo = Integer.parseInt(Integer.toString(/*name given to card array*/[0]) + Integer.toString(/*name given to card array*/[1]));
        /**
         * Pull last two digits, convert to Strings, concate them, then convert
         * back to an integer value. This will be just like the one above but will use 
         * different element locations. Remember, array counts begin at zero.
         */
        lastTwo = /*similar to firstTwo formula above*/

        //Compare results
        if (/*add the two variables above to determined values = 100*/) {
           //If condition 7 is good
            //set boolean allGood to true
            //send allGood to setVerify method
        } else {
            //If condition 7 is bad
            //set boolean allGood to false
            //send allGood to setVerify method
        }
    }
} //End Subclass VerifyCard_Skeleton
