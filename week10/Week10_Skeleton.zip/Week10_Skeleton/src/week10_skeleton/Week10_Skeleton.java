package week10_skeleton;

/** 
 * @Course: SDEV 250 ~ Java Programming I
 * @Author Name: Steven Hickey
 * @Assignment Name: week10_skeleton
 * @Date: Nov 14, 2016 (Updated 4/10/2017)
 * @Description: Skeleton Code
 */
//Imports
import java.util.Scanner;

//Begin Class Week10_Skeleton
public class Week10_Skeleton {

    //Begin Main Method
    public static void main(String[] args) {
        
        /**Declarations
         * To include Strings for name, date, card number and loop answer
         */

        //New Scanner object here
        
        //Begin loop to run until user decides to exit
        do {
            System.out.print("Enter Card Holder's Name: ");
            /*Name of variable assigned to CC user name*/ = sc.nextLine();
            System.out.print("Enter Credit Card Number (No dashes): ");
            /*Name of variable assigned to CC number*/ = sc.nextLine();
            System.out.print("Enter Credit Card Expiration Date (MM/YY): ");
            /*Name of variable assigned to CC date*/ = sc.nextLine();

            /**
             * Create a new sublcass object here and send user entered data to the 
             * objects constructor. The constructor must receive all three in the
             * same order they are sent and same variable type.
             */

            /**
             * Call sublcass get method that will send a final boolean value that
             * is set after all the conditions have been checked.
             */
            if (/*Name of subclass assigned above*/./*name of get method used for verification*/()) {
                System.out.printf("\n%s's card number: %s is a valid credit card.\n",/*/*name of get method to get name, Name of variable assigned to CC number*/);
            } else {
                System.out.printf("\n%s's card number: %s is NOT a valid credit card.\n",/*/*name of get method to get name, Name of variable assigned to CC number*/);    
            }
            System.out.print("\nRun program again? (Y for Yes, N for No): ");
            /*Name of variable assigned to looping*/ = sc.nextLine();
            //End loop
        } while (/*Name of variable assigned to looping*/.equalsIgnoreCase("Y"));
        System.out.println("Thank you. Goodbye!");
    } //End Main Method
} //End Class Week10_Skeleton