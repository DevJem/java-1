package week3;

/**
 * @Course: SDEV 250 ~ Java Programming I
 * @Author Name: Jeremy DeHay
 * @Assignment Name: week3
 * @Date: Sep 15, 2017
 * @Description: This program determines the area of several geometric shapes 
 * from a menu. The menu repeats until the user chooses to exit the program.
 * The user decides which shape and enters the sizes required. This program
 * utilizes both if/else statements and switch blocks to perform the same task,
 * with one being commented out each time the program is run. After the
 * calculations are called, they send their results to a report method that
 * generates a standard output.
 */

//Imports
import static java.lang.Math.*;
import java.util.Scanner;

//Begin Class Week3
public class Week3 {

    /* input scanner for global user input */
    static Scanner input = new Scanner(System.in);

    //Begin Main Method
    public static void main(String[] args) {

        /* 
         * This loop maintains the menu until the exit option is chosen
         */
        while (true) {
            /* reset the value each time the menu is shown */
            int chosenValue = 0;

            /* Loop to validate input */
            while (true) {
                System.out.println("Please select an area to determine from the "
                        + "following menu choices:");
                displayMenu();
                chosenValue = input.nextInt();
                if (chosenValue < 1 || chosenValue > 5) {
                    System.out.println("Invalid selection, try again.\n");
                } else {
                    break;
                }
            }

            /**
             * Toggle between these two methods by commenting only one out at a
             * time in order to swap between using a switch block and an if/else
             * statement.
             */
            useIfElse(chosenValue);
//            useSwitch(chosenValue);
        }
    }  //End Main Method

    /* Displays the menu */
    private static void displayMenu() {
        System.out.println("1. Determine the area of a Square");
        System.out.println("2. Determine the area of a Circle");
        System.out.println("3. Determine the area of an Ellipse");
        System.out.println("4. Determine the area of a Pentagon");
        System.out.println("5. Exit");
        System.out.print("Choice: ");
    }

    /**
     * Using two different methods is a convenient way to manage swapping
     * between the switch and the if/else statement.
     */
    
    /*
     * This method gets the menu choice passed into it and uses if/else to
     * determine which calculation should be used.
     */
    private static void useIfElse(int val) {
        if (val == 1) {
            calcSquare();
        } else if (val == 2) {
            calcCircle();
        } else if (val == 3) {
            calcEllipse();
        } else if (val == 4) {
            calcPentagon();
        } else if (val == 5) {
            System.out.println("Goodbye!");
            System.exit(0);
        } else {
            /* really not needed since you can't have any other options */
            System.out.println("Something crazy has happened! Exiting NOW!");
            System.exit(1);
        }
    }

    /*
     * This method gets the menu choice passed into it and uses a switch to
     * determine which calculation should be used.
     */
    private static void useSwitch(int val) {
        switch (val) {
            case 1:
                calcSquare();
                break;
            case 2:
                calcCircle();
                break;
            case 3:
                calcEllipse();
                break;
            case 4:
                calcPentagon();
                break;
            case 5:
                System.out.println("Goodbye!");
                System.exit(0);
                break;

            /* really not needed since you can't have any other options */
            default:
                System.out.println("Something crazy has happened! Exiting NOW!");
                System.exit(1);
                break;
        }
    }

    /* 
     * Calculates the area of a square and sends the appropriate info to the
     * report method.
     */
    private static void calcSquare() {
        double length;
        double area;
        String type = "Square";
        String formula = "Area = length^2";

        System.out.print("Enter the length of one side of the square: ");
        length = input.nextDouble();

        area = pow(length, 2);
        report(area, type, formula);
    }

    /* 
     * Calculates the area of a circle and sends the appropriate info to the
     * report method.
     */
    private static void calcCircle() {
        double radius;
        double area;
        String type = "Circle";
        String formula = "Area = PI * radius^2";

        System.out.print("Enter the radius of the circle: ");
        radius = input.nextDouble();

        area = PI * pow(radius, 2);
        report(area, type, formula);
    }

    /* 
     * Calculates the area of an ellispe and sends the appropriate info to the
     * report method.
     */
    private static void calcEllipse() {
        double radius1;
        double radius2;
        double area;
        String type = "Ellipse";
        String formula = "Area = PI * radius1 * radius2";

        System.out.print("Enter the smaller radius of the ellipse: ");
        radius1 = input.nextDouble();
        System.out.print("Enter the larger radius of the ellipse: ");
        radius2 = input.nextDouble();

        area = PI * radius1 * radius2;
        report(area, type, formula);
    }

    /* 
     * Calculates the area of a pentagon and sends the appropriate info to the
     * report method.
     */
    private static void calcPentagon() {
        double length;
        double area;
        String type = "Pentagon";
        String formula = "Area = 1/4 * sqrt(5 (5 + 2 * sqrt(5))) * length^2";

        System.out.print("Enter the length of one side of the pentagon: ");
        length = input.nextDouble();

        area = .25 * sqrt(5 * (5 + 2 * sqrt(5))) * pow(length, 2);
        report(area, type, formula);
    }

    /* 
     * Recieves info from calculation methods to create a standard output.
     */
    private static void report(double area, String type, String formula) {
        System.out.println("\nThe formula for " + type + " is: " + formula);
        System.out.println("The area of your " + type + " is: " + area + "!\n");
    }

}  //End Class Week3

