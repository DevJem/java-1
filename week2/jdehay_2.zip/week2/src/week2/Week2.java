package week2;

/**
  *  @Course: SDEV 250 ~ Java Programming I
  *  @Author Name: Jeremy DeHay
  *  @Assignment Name: week2
  *  @Date: Sep 7, 2017
  *  @Description: This program prompts the user to enter side A and side B
  *                of a triangle. It then determines the acreage that would
  *                fit in that area. Finally, it outputs to the user the length
  *                of side C and the total acreage.
  */
//Imports
import static java.lang.Math.*;
import java.util.Scanner;

//Begin Class Week2
public class Week2 {

    //Begin Main Method
    public static void main(String[] args) {
        
        /* Variables */
        final double ACRE = 43560;
        int sideA, sideB;
        double sideC, area, acreage;
        Scanner input = new Scanner(System.in);
        
        /* Get inputs */
        System.out.print("Please enter side A in feet: ");
        sideA = input.nextInt();
        System.out.print("Please enter side B in feet: ");
        sideB = input.nextInt();
        
        /* Do maths */
        sideC = sqrt( pow(sideA, 2) + pow(sideB, 2) );
        area = (sideA * sideB) / 2;
        acreage = area / ACRE;
        
        /* Print outputs */
        System.out.println("The length of side C is " + sideC);
        System.out.println("The acreage of your land is " + acreage);

    }  //End Main Method

}  //End Class Week2

