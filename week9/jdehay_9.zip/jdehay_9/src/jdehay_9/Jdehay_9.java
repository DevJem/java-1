package jdehay_9;
/**
  *  @Course: SDEV 250 ~ Java Programming I
  *  @Author Name: Jeremy DeHay
  *  @Assignment Name: jdehay_9
  *  @Date: Oct 27, 2017
  *  @Description: This program takes user input for last month's and the 
  *                current month's KwHs, sends those values to the MyUtility 
  *                class, displays the amount used, the subtotal, the taxes,
  *                and the total bill.
  */

//Imports
import java.util.InputMismatchException;
import java.util.Scanner;

//Begin Class Jdehay_9
public class Jdehay_9 {

    //Begin Main Method
    public static void main(String[] args) {
        
        /* Input scanner */
        Scanner input = new Scanner(System.in);
        
        /* variables */
        double lastMonth;
        double currentMonth;
        char cont;

        /* Validate entries for last month and current month meter readings */
        while (true) {
            try {
                System.out.print("Enter last month's KwHs usage: ");
                lastMonth = input.nextDouble();
                System.out.print("Enter the current month's KwHs usage: ");
                currentMonth = input.nextDouble();
                if (currentMonth < lastMonth) {
                    System.out.println("Current usage must be greater than"
                            + "previous usage.");
                    continue;
                }
            } catch (InputMismatchException e) {
                input.nextLine();
                System.out.println("Input error, please start over.");
                continue;
            }
            
            /* Calculate usage, rate, subtotal, and taxes owed through the
               MyUtility object
            */
            MyUtility calculate = new MyUtility(lastMonth, currentMonth);
            
            /* Output calculation results using class get methods */
            System.out.printf("Your usage was: %.1f KwHs\n", calculate.getUsage());
            System.out.printf("Your rate is: $%.4f/KwH\n", calculate.getRate());
            System.out.printf("Your subtotal was: $%.2f\n", calculate.getSubtotal());
            System.out.printf("The taxes come to: $%.2f\n", calculate.getTaxOwed());
            System.out.printf("The total bill is: $%.2f\n", calculate.getFinalBill());

            /* Check if user wants to try again */
            while (true) {
                System.out.print("Would you like to calculate a new total? (Y for "
                        + "Yes, N to exit) ");
                try {
                    /* This picks the first letter of the response */
                    cont = input.next().charAt(0);
                } catch (InputMismatchException e) {
                    input.nextLine();  // clears input buffer
                    continue;          // skips the String validation
                }
                if (String.valueOf(cont).equalsIgnoreCase("n")) {
                    System.out.println("Goodbye!");
                    System.exit(0);
                    break;
                } else if (String.valueOf(cont).equalsIgnoreCase("y")) {
                    break;
                } else {
                    System.out.println("Invalid option");
                }
            }
        }  // End loop to keep program going
    }  //End Main Method
}  //End Class Jdehay_9

/*
 (                         *     
 )\ )                    (  `    
(()/(  (   (   (  (  (   )\))(   
 /(_)) )\  )\  )\ )\ )\ ((_)()\  
(_))_ ((_)((_)((_|(_|(_)(_()((_) 
 |   \| __\ \ / / | | __|  \/  | 
 | |) | _| \ V / || | _|| |\/| | 
 |___/|___| \_/ \__/|___|_|  |_| 
      https://is.gd/RGR0UQ                  
*/