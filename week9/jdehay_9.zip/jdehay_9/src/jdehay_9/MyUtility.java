package jdehay_9;

/**
  *  @Course: SDEV 250 ~ Java Programming I
  *  @Author Name: Jeremy DeHay
  *  @Assignment Name: jdehay_9
  *  @Date: Oct 27, 2017
  *  @Subclass MyUtility Description: keeps values secure and private while
  *            performing calculations based on the data sent from the main
  *            class.
  */
//Imports

//Begin Subclass MyUtility
public class MyUtility {
    
    /* private variables only usable by the MyUtility class */
    private double usage;
    private double rate;
    private double subtotal;
    private double finalBill;
    private double taxOwed;
    
    private final double RATE_A = .0809;
    private final double RATE_B = .091;
    private final double RATE_C = .109;
    private final double TAX = .0346;
    
    /* Default constructor */
    public MyUtility() {
        setUsage(0, 0);
        setRate(usage);
        setSubtotal(usage, rate);
        setTaxOwed(subtotal);
        setFinalBill(subtotal, taxOwed);
    }
    
    /* Constructor sets reading values */
    public MyUtility(double lastMonth, double currentMonth) {
        setUsage(lastMonth, currentMonth);
        setRate(usage);
        setSubtotal(usage, rate);
        setTaxOwed(subtotal);
        setFinalBill(subtotal, taxOwed);
    }
    
    /**
     * Get and set methods for manipulating and returning the required rate
     * @param usage 
     * @return returns the set rate
     */
    private void setRate(double usage) {
        if (usage > 900) {
            rate = RATE_C;
        } else if (usage > 500) {
            rate = RATE_B;
        } else
            rate = RATE_A;
    }
    
    public double getRate() {
        return rate;
    }
    
    /**
     * get and set methods to calculate and return the usage times the rate to 
     * find a subtotal.
     * @param usage
     * @param rate
     * @return subtotla
     */
    private void setSubtotal(double usage, double rate) {
        subtotal = usage * rate;
    }
    
    public double getSubtotal() {
        return subtotal;
    }    
    
    /**
     * Get and set methods for the calculation of the final bill, which includes
     * the subtotal and the taxes owed.
     * @param subtotal
     * @param taxOwed 
     */
    private void setFinalBill(double subtotal, double taxOwed) {
        finalBill = subtotal + taxOwed;
    }
    
    public double getFinalBill() {
        return finalBill;
    }
    
    /**
     * GetUsage just finds the difference between the two months' usages.
     * @param lastMonth
     * @param currentMonth
     * @return usage
     */
    private void setUsage(double lastMonth, double currentMonth) {
        usage = currentMonth - lastMonth;
    }
    
    public double getUsage() {
        return usage;
    }
    
    /**
     * get and set methods for the tax owed based on the subtotal
     * @param subtotal
     * @return the taxes owed
     */
    private void setTaxOwed(double subtotal) {
        taxOwed = subtotal * TAX;
    }
    
    double getTaxOwed() {
        return taxOwed;
    }

} // End Subclass MyUtility

/*
 (                         *     
 )\ )                    (  `    
(()/(  (   (   (  (  (   )\))(   
 /(_)) )\  )\  )\ )\ )\ ((_)()\  
(_))_ ((_)((_)((_|(_|(_)(_()((_) 
 |   \| __\ \ / / | | __|  \/  | 
 | |) | _| \ V / || | _|| |\/| | 
 |___/|___| \_/ \__/|___|_|  |_| 
      https://is.gd/RGR0UQ                  
*/