package Assignment;

/**
 * @Course: SDEV 250 ~ Java Programming I
 * @Author Name: Jeremy DeHay
 * @Assignment Name: Assignment
 * @Date: Aug 29, 2017
 * @Subclass Assignment Description: This program prints out a Haiku in
 * five lines using 6 System.out print commands.
 */
//Imports
//Begin Subclass Assignment1
public class Assignment1 {

    public static void main(String[] args) {

        /* System.out.println adds a newline character at the end */
        System.out.println("This is my Haiku");
        System.out.println("It is a Java Haiku");
        System.out.println("With Five Seven Five");
        
        /* Using System.out.print doesn't add any whitespace or newlines */
        System.out.print("That means it has 5 syllables, then 7 syllables, ");
        System.out.println("then 5 syllables yet again.");
        System.out.println("That means there are a total of " + (7 + 10) + " syllables in a Haiku");

    }

} // End Subclass Assignment1
