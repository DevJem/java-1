package jdehay_5;

/**
  *  @Course: SDEV 250 ~ Java Programming I
  *  @Author Name: Jeremy DeHay
  *  @Assignment Name: jdehay_5
  *  @Date: Sep 25, 2017
  *  @Description: This program determines the factorial from 1 through a user
  *                entered value and displays them.
  */

//Imports
import java.math.BigInteger;
import java.util.InputMismatchException;
import java.util.Scanner;

//Begin Class Jdehay_5
public class Jdehay_5 {
    
    // New global scanner object
    private static final Scanner INPUT = new Scanner(System.in);

    //Begin Main Method
    public static void main(String[] args) {
        
        // variables
        int choice = 0;
        
        // Initial menu
        System.out.println("Welcome to my factorial program! Please choose from"
                + " the following: ");
        System.out.println("1. Run Program");
        System.out.println("2. Exit Program");

        /* accepts and validates menu choice */
        while (true) {
            try {
                choice = INPUT.nextInt();
            } catch (InputMismatchException e) {
                System.out.println("You have entered an invalid choice. "
                            + "Please try again.");
                INPUT.nextLine();  // clears INPUT buffer
                continue;          // skips the integer validation
            }
            
            /* input validation */
            if (choice == 1 || choice == 2) {
                break;
            } else {
                System.out.println("You have entered an invalid choice. "
                        + "Please try again.");
            }
        }

        /* Menu option results */
        switch (choice) {
            /* This case uses fall through. When the factorial loop is complete
               it falls to the exit case.
            */
            case 1:
                do {
                    // Loops the method if asked to continue
                }while(factorial());
            case 2:
                System.out.println("Thanks for playing! Goodbye!");
                System.exit(0);
            default:
                System.out.println("Something crazy has happened... Punting!!");
                System.exit(1);
        }
    }  //End Main Method

    /**
     * factorial() method shows the starting number, asks for an ending number,
     * validates the user's input, and prints out each of the factorials from 
     * the starting number to the ending number. It then asks if the user wants
     * to continue using the program and returns true to the original while
     * loop if they do, false if they do not.
     * @return boolean cont
     */
    private static boolean factorial() {
        int start = 1;        // More portable than hard coded
        int end = 0;
        char runAgain;        // whether or not the user wants to continue
        boolean cont = true;  // return value of the method
        BigInteger count = BigInteger.valueOf(1);
        
        /* Accepts and validates an ending value */
        while (true) {
            System.out.printf("The starting number is %d\n", start);
            System.out.print("Please enter an ending integer value: ");
            try {
                end = INPUT.nextInt();
            } catch (InputMismatchException e) {
                INPUT.nextLine();  // clears INPUT buffer
                continue;          // skips the integer validation
            }
            
            /* make sure user entered something useful */
            if (end > 0) {
                break;
            }
        }
        
        /**
         * This math magic starts with count at 1 and multiplies it by the 
         * iteration of j, which is initialized to i. Then, if > 1, subtracts 1 
         * from the iteration value and multiplies count by the result. This 
         * continues until j = 1 because it doesn't matter what count * 1 is.
         */
        for (int i = 1; i <= end; i++) {
            for (int j = i; j > 1; j--) {
                count = count.multiply(BigInteger.valueOf(j));
            }
            
            System.out.printf("%d! = %d\n", i, count);
            count = BigInteger.valueOf(1);  // reset count for next number
        }
        
        /* Accepts and validates whether or not to run the program again */
        while (true) {
            System.out.print("Run factorial program again? (Y for Yes, N for No): ");
            try {
                /* This picks the first letter of the response */
                runAgain = INPUT.next().charAt(0);
            } catch (InputMismatchException e) {
                INPUT.nextLine();  // clears INPUT buffer
                continue;          // skips the String validation
            }
            if (String.valueOf(runAgain).equalsIgnoreCase("n")) {
                cont = false;      // skip to exit
                break;
            } else if (String.valueOf(runAgain).equalsIgnoreCase("y")) {
                break;
            } else {
                System.out.println("Invalid option");
            }
        }
        /* Loops the method without continuously adding it to the stack */
        return cont;
    }
}  //End Class Jdehay_5